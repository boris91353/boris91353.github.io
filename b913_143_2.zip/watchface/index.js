﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_altimeter_pointer_progress_img_pointer = ''
        let normal_altimeter_icon_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_step_icon_img = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 16;
        let normal_step_TextCircle_img_height = 26;
        let normal_step_TextCircle_unit = null;
        let normal_step_TextCircle_unit_width = 32;
        let normal_step_pointer_progress_img_pointer = ''
        let normal_moon_image_progress_img_level = ''
        let normal_pai_total_TextCircle = new Array(3);
        let normal_pai_total_TextCircle_ASCIIARRAY = new Array(10);
        let normal_pai_total_TextCircle_img_width = 16;
        let normal_pai_total_TextCircle_img_height = 26;
        let normal_pai_total_TextCircle_unit = null;
        let normal_pai_total_TextCircle_unit_width = 37;
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 16;
        let normal_calorie_TextCircle_img_height = 26;
        let normal_calorie_TextCircle_unit = null;
        let normal_calorie_TextCircle_unit_width = 32;
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_city_name_text = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_battery_circle_scale = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 16;
        let normal_battery_TextCircle_img_height = 26;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 32;
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 16;
        let normal_distance_TextCircle_img_height = 26;
        let normal_distance_TextCircle_unit = null;
        let normal_distance_TextCircle_unit_width = 32;
        let normal_distance_TextCircle_dot_width = 9;
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let idle_background_bg = ''
        let idle_altimeter_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_step_icon_img = ''
        let idle_step_circle_scale = ''
        let idle_step_TextCircle = new Array(5);
        let idle_step_TextCircle_ASCIIARRAY = new Array(10);
        let idle_step_TextCircle_img_width = 16;
        let idle_step_TextCircle_img_height = 26;
        let idle_step_TextCircle_unit = null;
        let idle_step_TextCircle_unit_width = 32;
        let idle_battery_circle_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_TextCircle = new Array(3);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 16;
        let idle_battery_TextCircle_img_height = 26;
        let idle_battery_TextCircle_unit = null;
        let idle_battery_TextCircle_unit_width = 32;
        let idle_image_img = ''
        let idle_fat_burning_TextCircle = new Array(3);
        let idle_fat_burning_TextCircle_ASCIIARRAY = new Array(10);
        let idle_fat_burning_TextCircle_img_width = 16;
        let idle_fat_burning_TextCircle_img_height = 26;
        let idle_fat_burning_TextCircle_unit = null;
        let idle_fat_burning_TextCircle_unit_width = 32;
        let idle_spo2_text_text_img = ''
        let idle_spo2_text_separator_img = ''
        let idle_pai_total_TextCircle = new Array(3);
        let idle_pai_total_TextCircle_ASCIIARRAY = new Array(10);
        let idle_pai_total_TextCircle_img_width = 16;
        let idle_pai_total_TextCircle_img_height = 26;
        let idle_pai_total_TextCircle_unit = null;
        let idle_pai_total_TextCircle_unit_width = 37;
        let idle_calorie_TextCircle = new Array(4);
        let idle_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let idle_calorie_TextCircle_img_width = 16;
        let idle_calorie_TextCircle_img_height = 26;
        let idle_calorie_TextCircle_unit = null;
        let idle_calorie_TextCircle_unit_width = 32;
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_wind_text_text_img = ''
        let idle_wind_text_separator_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_heart_rate_TextCircle = new Array(3);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 16;
        let idle_heart_rate_TextCircle_img_height = 26;
        let idle_heart_rate_TextCircle_unit = null;
        let idle_heart_rate_TextCircle_unit_width = 32;
        let idle_distance_TextCircle = new Array(5);
        let idle_distance_TextCircle_ASCIIARRAY = new Array(10);
        let idle_distance_TextCircle_img_width = 16;
        let idle_distance_TextCircle_img_height = 26;
        let idle_distance_TextCircle_unit = null;
        let idle_distance_TextCircle_unit_width = 32;
        let idle_distance_TextCircle_dot_width = 9;
        let idle_digital_clock_img_time_hour = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let normal_heart_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'baro_018_14.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -388,
              end_angle: 1383,
              invalid_visible: false,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sector_0036.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_0009.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0018_52_07.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0730.png","0731.png","0732.png","0733.png","0734.png","0735.png","0736.png","0737.png","0738.png","0739.png"],
              // radius: 213,
              // angle: 154,
              // char_space_angle: 1,
              // unit: 'steps_0008.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = '0730.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '0731.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '0732.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '0733.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '0734.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '0735.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '0736.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '0737.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '0738.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '0739.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 + 200,
                src: '0730.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_step_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_step_TextCircle_unit_width / 2,
              pos_y: 240 + 200,
              src: 'steps_0008.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'steps_0010.png',
              center_x: 240,
              center_y: 240,
              x: 0,
              y: 193,
              start_angle: 224,
              end_angle: 137,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 221,
              y: 88,
              image_array: ["Moon_201.png","Moon_202.png","Moon_203.png","Moon_204.png","Moon_205.png","Moon_206.png","Moon_207.png","Moon_208.png","Moon_209.png","Moon_210.png","Moon_211.png","Moon_212.png","Moon_213.png","Moon_214.png","Moon_215.png","Moon_216.png","Moon_217.png","Moon_218.png","Moon_219.png","Moon_220.png","Moon_221.png","Moon_222.png","Moon_223.png","Moon_224.png","Moon_225.png","Moon_226.png","Moon_227.png","Moon_228.png","Moon_229.png","Moon_230.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_pai_total_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0710.png","0711.png","0712.png","0713.png","0714.png","0715.png","0716.png","0717.png","0718.png","0719.png"],
              // radius: 210,
              // angle: 113,
              // char_space_angle: 1,
              // unit: 'pai_0016_5.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_pai_total_TextCircle_ASCIIARRAY[0] = '0710.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[1] = '0711.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[2] = '0712.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[3] = '0713.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[4] = '0714.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[5] = '0715.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[6] = '0716.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[7] = '0717.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[8] = '0718.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[9] = '0719.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_pai_total_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_pai_total_TextCircle_img_width / 2,
                pos_y: 240 + 197,
                src: '0710.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_pai_total_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_pai_total_TextCircle_unit_width / 2,
              pos_y: 240 + 197,
              src: 'pai_0016_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0710.png","0711.png","0712.png","0713.png","0714.png","0715.png","0716.png","0717.png","0718.png","0719.png"],
              // radius: 210,
              // angle: 250,
              // char_space_angle: 1,
              // unit: '0179.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = '0710.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = '0711.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = '0712.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = '0713.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = '0714.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = '0715.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = '0716.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = '0717.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = '0718.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = '0719.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 240 + 197,
                src: '0710.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_calorie_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_calorie_TextCircle_unit_width / 2,
              pos_y: 240 + 197,
              src: '0179.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 229,
              src: '0176_4.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 316,
              src: '0174_4.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 268,
              src: '0175_5.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 199,
              font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 193,
              src: 'wind_0008.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 140,
              y: 104,
              image_array: ["w_0062.png","w_0063.png","w_0064.png","w_0065.png","w_0066.png","w_0067.png","w_0068.png","w_0069.png","w_0070.png","w_0071.png","w_0072.png","w_0073.png","w_0074.png","w_0075.png","w_0076.png","w_0077.png","w_0078.png","w_0079.png","w_0080.png","w_0081.png","w_0082.png","w_0083.png","w_0084.png","w_0085.png","w_0086.png","w_0087.png","w_0088.png","w_0089.png","w_0090.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 175,
              font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0125_5.png',
              unit_tc: '0125_5.png',
              unit_en: '0125_5.png',
              negative_image: '0128_3.png',
              invalid_image: '0128.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 202,
              y: 190,
              w: 184,
              h: 39,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFB33400,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 206,
              font_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sun_0118.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 67,
              y: 167,
              src: 'sun_0125.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 206,
              font_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sun_0118.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 371,
              y: 166,
              src: 'sun_0126.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sun_0006.png',
              center_x: 240,
              center_y: 240,
              x: 10,
              y: 184,
              start_angle: -64,
              end_angle: 59,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 136,
              font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 171,
              image_array: ["0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'ball.png',
              center_x: 299,
              center_y: 154,
              x: 8,
              y: 49,
              start_angle: -187,
              end_angle: 137,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 92,
              // end_angle: 36,
              // radius: 230,
              // line_width: 40,
              // line_cap: Flat,
              // color: 0xFF7F7F7F,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 36,
              end_angle: 92,
              radius: 210,
              line_width: 40,
              corner_flag: 3,
              color: 0xFF7F7F7F,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0740.png","0741.png","0742.png","0743.png","0744.png","0745.png","0746.png","0747.png","0748.png","0749.png"],
              // radius: 210,
              // angle: 62,
              // char_space_angle: 1,
              // unit: 'bat_0018_2.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = '0740.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = '0741.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = '0742.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = '0743.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = '0744.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = '0745.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = '0746.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = '0747.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = '0748.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = '0749.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 - 223,
                src: '0740.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 240 - 223,
              src: 'bat_0018_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0710.png","0711.png","0712.png","0713.png","0714.png","0715.png","0716.png","0717.png","0718.png","0719.png"],
              // radius: 213,
              // angle: 206,
              // char_space_angle: 1,
              // unit: 'location_0008.png',
              // dot_image: '0126_3.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = '0710.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = '0711.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = '0712.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = '0713.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = '0714.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = '0715.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = '0716.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = '0717.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = '0718.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = '0719.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_distance_TextCircle_img_width / 2,
                pos_y: 240 + 200,
                src: '0710.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 240 + 200,
              src: 'location_0008.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 77,
              hour_startY: 232,
              hour_array: ["0620.png","0621.png","0622.png","0623.png","0624.png","0625.png","0626.png","0627.png","0628.png","0629.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 258,
              minute_startY: 232,
              minute_array: ["0630.png","0631.png","0632.png","0633.png","0634.png","0635.png","0636.png","0637.png","0638.png","0639.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 219,
              day_startY: 16,
              day_sc_array: ["day_0001.png","day_0002.png","day_0003.png","day_0004.png","day_0005.png","day_0006.png","day_0007.png","day_0008.png","day_0009.png","day_0010.png"],
              day_tc_array: ["day_0001.png","day_0002.png","day_0003.png","day_0004.png","day_0005.png","day_0006.png","day_0007.png","day_0008.png","day_0009.png","day_0010.png"],
              day_en_array: ["day_0001.png","day_0002.png","day_0003.png","day_0004.png","day_0005.png","day_0006.png","day_0007.png","day_0008.png","day_0009.png","day_0010.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 138,
              y: 22,
              week_en: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              week_tc: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              week_sc: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 269,
              month_startY: 21,
              month_sc_array: ["month_0001.png","month_0002.png","month_0003.png","month_0004.png","month_0005.png","month_0006.png","month_0007.png","month_0008.png","month_0009.png","month_0010.png","month_0011.png","month_0012.png"],
              month_tc_array: ["month_0001.png","month_0002.png","month_0003.png","month_0004.png","month_0005.png","month_0006.png","month_0007.png","month_0008.png","month_0009.png","month_0010.png","month_0011.png","month_0012.png"],
              month_en_array: ["month_0001.png","month_0002.png","month_0003.png","month_0004.png","month_0005.png","month_0006.png","month_0007.png","month_0008.png","month_0009.png","month_0010.png","month_0011.png","month_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'baro_018_17.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -489,
              end_angle: 1370,
              invalid_visible: false,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minut_0010.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0018_74_11_6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 230,
              // end_angle: 310,
              // radius: 129,
              // line_width: 40,
              // line_cap: Flat,
              // color: 0xFF595959,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 230,
              end_angle: 310,
              radius: 109,
              line_width: 40,
              corner_flag: 3,
              color: 0xFF595959,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              // radius: 210,
              // angle: 172,
              // char_space_angle: 1,
              // unit: 'steps_0009.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextCircle_ASCIIARRAY[0] = '0700.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[1] = '0701.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[2] = '0702.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[3] = '0703.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[4] = '0704.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[5] = '0705.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[6] = '0706.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[7] = '0707.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[8] = '0708.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[9] = '0709.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_step_TextCircle_img_width / 2,
                pos_y: 240 + 197,
                src: '0700.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_step_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_step_TextCircle_unit_width / 2,
              pos_y: 240 + 197,
              src: 'steps_0009.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 127,
              // end_angle: 71,
              // radius: 229,
              // line_width: 40,
              // line_cap: Flat,
              // color: 0xFFADADAD,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 71,
              end_angle: 127,
              radius: 209,
              line_width: 40,
              corner_flag: 3,
              color: 0xFFADADAD,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bat_0023_5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              // radius: 210,
              // angle: 61,
              // char_space_angle: 1,
              // unit: 'bat_0018_3.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = '0700.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = '0701.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = '0702.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = '0703.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = '0704.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = '0705.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = '0706.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = '0707.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = '0708.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = '0709.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_battery_TextCircle_img_width / 2,
                pos_y: 240 - 223,
                src: '0700.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_battery_TextCircle_unit_width / 2,
              pos_y: 240 - 223,
              src: 'bat_0018_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'steps_0028.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_fat_burning_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              // radius: 161,
              // angle: 290,
              // char_space_angle: 1,
              // unit: 'fat_burning_08.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_fat_burning_TextCircle_ASCIIARRAY[0] = '0700.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[1] = '0701.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[2] = '0702.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[3] = '0703.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[4] = '0704.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[5] = '0705.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[6] = '0706.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[7] = '0707.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[8] = '0708.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[9] = '0709.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_fat_burning_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_fat_burning_TextCircle_img_width / 2,
                pos_y: 240 - 174,
                src: '0700.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_fat_burning_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_fat_burning_TextCircle_unit_width / 2,
              pos_y: 240 - 174,
              src: 'fat_burning_08.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_fat_burning_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 331,
              font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 327,
              src: 'oxygen_0002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_pai_total_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              // radius: 161,
              // angle: 248,
              // char_space_angle: 1,
              // unit: 'pai_0016_7.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_pai_total_TextCircle_ASCIIARRAY[0] = '0700.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[1] = '0701.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[2] = '0702.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[3] = '0703.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[4] = '0704.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[5] = '0705.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[6] = '0706.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[7] = '0707.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[8] = '0708.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[9] = '0709.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_pai_total_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_pai_total_TextCircle_img_width / 2,
                pos_y: 240 - 174,
                src: '0700.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_pai_total_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_pai_total_TextCircle_unit_width / 2,
              pos_y: 240 - 174,
              src: 'pai_0016_7.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              // radius: 158,
              // angle: 191,
              // char_space_angle: 2,
              // unit: '0179_2.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextCircle_ASCIIARRAY[0] = '0700.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[1] = '0701.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[2] = '0702.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[3] = '0703.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[4] = '0704.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[5] = '0705.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[6] = '0706.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[7] = '0707.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[8] = '0708.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[9] = '0709.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_calorie_TextCircle_img_width / 2,
                pos_y: 240 + 145,
                src: '0700.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_calorie_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_calorie_TextCircle_unit_width / 2,
              pos_y: 240 + 145,
              src: '0179_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 229,
              src: '0176_4.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 280,
              src: '0174_4.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 268,
              src: '0175_5.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 106,
              image_array: ["Moon_201.png","Moon_202.png","Moon_203.png","Moon_204.png","Moon_205.png","Moon_206.png","Moon_207.png","Moon_208.png","Moon_209.png","Moon_210.png","Moon_211.png","Moon_212.png","Moon_213.png","Moon_214.png","Moon_215.png","Moon_216.png","Moon_217.png","Moon_218.png","Moon_219.png","Moon_220.png","Moon_221.png","Moon_222.png","Moon_223.png","Moon_224.png","Moon_225.png","Moon_226.png","Moon_227.png","Moon_228.png","Moon_229.png","Moon_230.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 71,
              font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 298,
              y: 65,
              src: 'wind_0007.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 205,
              y: 44,
              image_array: ["w_0101.png","w_0102.png","w_0103.png","w_0104.png","w_0105.png","w_0106.png","w_0107.png","w_0108.png","w_0109.png","w_0110.png","w_0111.png","w_0112.png","w_0113.png","w_0114.png","w_0115.png","w_0116.png","w_0117.png","w_0118.png","w_0119.png","w_0120.png","w_0121.png","w_0122.png","w_0123.png","w_0124.png","w_0125.png","w_0126.png","w_0127.png","w_0128.png","w_0129.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 71,
              font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0125_5.png',
              unit_tc: '0125_5.png',
              unit_en: '0125_5.png',
              negative_image: '0128_3.png',
              invalid_image: '0128.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 134,
              font_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sun_0118.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 101,
              src: 'sun_0125_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 134,
              font_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sun_0118.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 273,
              y: 101,
              src: 'sun_0126_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              // radius: 158,
              // angle: 170,
              // char_space_angle: 2,
              // unit: '0136.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = '0700.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = '0701.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = '0702.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = '0703.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = '0704.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = '0705.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = '0706.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = '0707.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = '0708.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = '0709.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 145,
                src: '0700.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_heart_rate_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_heart_rate_TextCircle_unit_width / 2,
              pos_y: 240 + 145,
              src: '0136.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // idle_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0700.png","0701.png","0702.png","0703.png","0704.png","0705.png","0706.png","0707.png","0708.png","0709.png"],
              // radius: 210,
              // angle: 189,
              // char_space_angle: 1,
              // unit: 'location_0009.png',
              // dot_image: '0126_4.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextCircle_ASCIIARRAY[0] = '0700.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[1] = '0701.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[2] = '0702.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[3] = '0703.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[4] = '0704.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[5] = '0705.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[6] = '0706.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[7] = '0707.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[8] = '0708.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[9] = '0709.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_distance_TextCircle_img_width / 2,
                pos_y: 240 + 197,
                src: '0700.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_distance_TextCircle_unit_width / 2,
              pos_y: 240 + 197,
              src: 'location_0009.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 174,
              hour_startY: 185,
              hour_array: ["0780.png","0781.png","0782.png","0783.png","0784.png","0785.png","0786.png","0787.png","0788.png","0789.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 219,
              day_startY: 16,
              day_sc_array: ["day_0001.png","day_0002.png","day_0003.png","day_0004.png","day_0005.png","day_0006.png","day_0007.png","day_0008.png","day_0009.png","day_0010.png"],
              day_tc_array: ["day_0001.png","day_0002.png","day_0003.png","day_0004.png","day_0005.png","day_0006.png","day_0007.png","day_0008.png","day_0009.png","day_0010.png"],
              day_en_array: ["day_0001.png","day_0002.png","day_0003.png","day_0004.png","day_0005.png","day_0006.png","day_0007.png","day_0008.png","day_0009.png","day_0010.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 138,
              y: 22,
              week_en: ["week_0011.png","week_0012.png","week_0013.png","week_0014.png","week_0015.png","week_0016.png","week_0017.png"],
              week_tc: ["week_0011.png","week_0012.png","week_0013.png","week_0014.png","week_0015.png","week_0016.png","week_0017.png"],
              week_sc: ["week_0011.png","week_0012.png","week_0013.png","week_0014.png","week_0015.png","week_0016.png","week_0017.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 269,
              month_startY: 21,
              month_sc_array: ["month_0021.png","month_0022.png","month_0023.png","month_0024.png","month_0025.png","month_0026.png","month_0027.png","month_0028.png","month_0029.png","month_0030.png","month_0031.png","month_0032.png"],
              month_tc_array: ["month_0021.png","month_0022.png","month_0023.png","month_0024.png","month_0025.png","month_0026.png","month_0027.png","month_0028.png","month_0029.png","month_0030.png","month_0031.png","month_0032.png"],
              month_en_array: ["month_0021.png","month_0022.png","month_0023.png","month_0024.png","month_0025.png","month_0026.png","month_0027.png","month_0028.png","month_0029.png","month_0030.png","month_0031.png","month_0032.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: Bluetooth_связь потяряна,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth_связь восстановлена,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth_связь потяряна"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth_связь восстановлена"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 249,
              y: 105,
              w: 100,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 232,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 232,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function text_update() {
              console.log('text_update()');

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 334;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  let normal_step_TextCircle_unit_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 213));
                  normal_step_TextCircle_unit_angle = toDegree(Math.atan2(normal_step_TextCircle_unit_width/2, 213));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + 1 * (normal_step_circle_string.length - 1) / 2;
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + (normal_step_TextCircle_img_angle + normal_step_TextCircle_unit_angle + 1) / 2;
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_step_TextCircle_unit_angle;
                  normal_step_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle pai_total_PAI');
              let totalPAI = pai.totalpai;
              let normal_pai_total_circle_string = parseInt(totalPAI).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 293;
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && normal_pai_total_circle_string.length > 0 && normal_pai_total_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_pai_total_TextCircle_img_angle = 0;
                  let normal_pai_total_TextCircle_dot_img_angle = 0;
                  let normal_pai_total_TextCircle_unit_angle = 0;
                  normal_pai_total_TextCircle_img_angle = toDegree(Math.atan2(normal_pai_total_TextCircle_img_width/2, 210));
                  normal_pai_total_TextCircle_unit_angle = toDegree(Math.atan2(normal_pai_total_TextCircle_unit_width/2, 210));
                  // alignment = CENTER_H
                  let normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_img_angle * (normal_pai_total_circle_string.length - 1);
                  normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_angleOffset + 1 * (normal_pai_total_circle_string.length - 1) / 2;
                  normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_angleOffset + (normal_pai_total_TextCircle_img_angle + normal_pai_total_TextCircle_unit_angle + 1) / 2;
                  normal_pai_total_TextCircle_angleOffset = -normal_pai_total_TextCircle_angleOffset;
                  char_Angle -= normal_pai_total_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_pai_total_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_pai_total_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_pai_total_TextCircle_img_width / 2);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, normal_pai_total_TextCircle_ASCIIARRAY[charCode]);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_pai_total_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_pai_total_TextCircle_unit_angle;
                  normal_pai_total_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 430;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  let normal_calorie_TextCircle_unit_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 210));
                  normal_calorie_TextCircle_unit_angle = toDegree(Math.atan2(normal_calorie_TextCircle_unit_width/2, 210));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + 1 * (normal_calorie_circle_string.length - 1) / 2;
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + (normal_calorie_TextCircle_img_angle + normal_calorie_TextCircle_unit_angle + 1) / 2;
                  normal_calorie_TextCircle_angleOffset = -normal_calorie_TextCircle_angleOffset;
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_calorie_TextCircle_unit_angle;
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 62;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 210));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 210));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + 1 * (normal_battery_circle_string.length - 1) / 2;
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 1) / 2;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_battery_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 386;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  let normal_distance_TextCircle_unit_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 213));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 213));
                  normal_distance_TextCircle_unit_angle = toDegree(Math.atan2(normal_distance_TextCircle_unit_width/2, 213));
                  // alignment = CENTER_H
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + 1 * (normal_distance_circle_string.length - 1) / 2;
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + (normal_distance_TextCircle_img_angle + normal_distance_TextCircle_unit_angle + 1) / 2;
                  normal_distance_TextCircle_angleOffset = -normal_distance_TextCircle_angleOffset;
                  char_Angle -= normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, '0126_3.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_distance_TextCircle_unit_angle;
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let idle_step_circle_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 352;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_circle_string.length > 0 && idle_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_step_TextCircle_img_angle = 0;
                  let idle_step_TextCircle_dot_img_angle = 0;
                  let idle_step_TextCircle_unit_angle = 0;
                  idle_step_TextCircle_img_angle = toDegree(Math.atan2(idle_step_TextCircle_img_width/2, 210));
                  idle_step_TextCircle_unit_angle = toDegree(Math.atan2(idle_step_TextCircle_unit_width/2, 210));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_step_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_step_TextCircle_img_width / 2);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.SRC, idle_step_TextCircle_ASCIIARRAY[charCode]);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_step_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_step_TextCircle_unit_angle;
                  idle_step_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 61;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  let idle_battery_TextCircle_unit_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 210));
                  idle_battery_TextCircle_unit_angle = toDegree(Math.atan2(idle_battery_TextCircle_unit_width/2, 210));
                  // alignment = CENTER_H
                  let idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_img_angle * (idle_battery_circle_string.length - 1);
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + 1 * (idle_battery_circle_string.length - 1) / 2;
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + (idle_battery_TextCircle_img_angle + idle_battery_TextCircle_unit_angle + 1) / 2;
                  char_Angle -= idle_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_battery_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_battery_TextCircle_unit_angle;
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle fat_burning_FAT_BURRING');
              let valueFatBurning = fat_burning.current;
              let idle_fat_burning_circle_string = parseInt(valueFatBurning).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_fat_burning_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 290;
                if (valueFatBurning != null && valueFatBurning != undefined && isFinite(valueFatBurning) && idle_fat_burning_circle_string.length > 0 && idle_fat_burning_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_fat_burning_TextCircle_img_angle = 0;
                  let idle_fat_burning_TextCircle_dot_img_angle = 0;
                  let idle_fat_burning_TextCircle_unit_angle = 0;
                  idle_fat_burning_TextCircle_img_angle = toDegree(Math.atan2(idle_fat_burning_TextCircle_img_width/2, 161));
                  idle_fat_burning_TextCircle_unit_angle = toDegree(Math.atan2(idle_fat_burning_TextCircle_unit_width/2, 161));
                  // alignment = CENTER_H
                  let idle_fat_burning_TextCircle_angleOffset = idle_fat_burning_TextCircle_img_angle * (idle_fat_burning_circle_string.length - 1);
                  idle_fat_burning_TextCircle_angleOffset = idle_fat_burning_TextCircle_angleOffset + 1 * (idle_fat_burning_circle_string.length - 1) / 2;
                  idle_fat_burning_TextCircle_angleOffset = idle_fat_burning_TextCircle_angleOffset + (idle_fat_burning_TextCircle_img_angle + idle_fat_burning_TextCircle_unit_angle + 1) / 2;
                  char_Angle -= idle_fat_burning_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_fat_burning_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_fat_burning_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_fat_burning_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_fat_burning_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_fat_burning_TextCircle_img_width / 2);
                      idle_fat_burning_TextCircle[index].setProperty(hmUI.prop.SRC, idle_fat_burning_TextCircle_ASCIIARRAY[charCode]);
                      idle_fat_burning_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_fat_burning_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_fat_burning_TextCircle_unit_angle;
                  idle_fat_burning_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_fat_burning_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle pai_total_PAI');
              let idle_pai_total_circle_string = parseInt(totalPAI).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 248;
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && idle_pai_total_circle_string.length > 0 && idle_pai_total_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_pai_total_TextCircle_img_angle = 0;
                  let idle_pai_total_TextCircle_dot_img_angle = 0;
                  let idle_pai_total_TextCircle_unit_angle = 0;
                  idle_pai_total_TextCircle_img_angle = toDegree(Math.atan2(idle_pai_total_TextCircle_img_width/2, 161));
                  idle_pai_total_TextCircle_unit_angle = toDegree(Math.atan2(idle_pai_total_TextCircle_unit_width/2, 161));
                  // alignment = CENTER_H
                  let idle_pai_total_TextCircle_angleOffset = idle_pai_total_TextCircle_img_angle * (idle_pai_total_circle_string.length - 1);
                  idle_pai_total_TextCircle_angleOffset = idle_pai_total_TextCircle_angleOffset + 1 * (idle_pai_total_circle_string.length - 1) / 2;
                  idle_pai_total_TextCircle_angleOffset = idle_pai_total_TextCircle_angleOffset + (idle_pai_total_TextCircle_img_angle + idle_pai_total_TextCircle_unit_angle + 1) / 2;
                  char_Angle -= idle_pai_total_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_pai_total_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_pai_total_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_pai_total_TextCircle_img_width / 2);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, idle_pai_total_TextCircle_ASCIIARRAY[charCode]);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_pai_total_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_pai_total_TextCircle_unit_angle;
                  idle_pai_total_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let idle_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 371;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_circle_string.length > 0 && idle_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_calorie_TextCircle_img_angle = 0;
                  let idle_calorie_TextCircle_dot_img_angle = 0;
                  let idle_calorie_TextCircle_unit_angle = 0;
                  idle_calorie_TextCircle_img_angle = toDegree(Math.atan2(idle_calorie_TextCircle_img_width/2, 158));
                  idle_calorie_TextCircle_unit_angle = toDegree(Math.atan2(idle_calorie_TextCircle_unit_width/2, 158));
                  // alignment = RIGHT
                  let idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_img_angle * (idle_calorie_circle_string.length - 1);
                  idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_angleOffset + 2 * (idle_calorie_circle_string.length - 1) / 2;
                  idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_angleOffset + (idle_calorie_TextCircle_img_angle + idle_calorie_TextCircle_unit_angle + 2) / 2;
                  idle_calorie_TextCircle_angleOffset = -idle_calorie_TextCircle_angleOffset;
                  char_Angle -= 2 * idle_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_calorie_TextCircle_img_width / 2);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, idle_calorie_TextCircle_ASCIIARRAY[charCode]);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_calorie_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_calorie_TextCircle_unit_angle;
                  idle_calorie_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 350;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  let idle_heart_rate_TextCircle_unit_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 158));
                  idle_heart_rate_TextCircle_unit_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_unit_width/2, 158));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_heart_rate_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_heart_rate_TextCircle_unit_angle;
                  idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let idle_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 369;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_circle_string.length > 0 && idle_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_distance_TextCircle_img_angle = 0;
                  let idle_distance_TextCircle_dot_img_angle = 0;
                  let idle_distance_TextCircle_unit_angle = 0;
                  idle_distance_TextCircle_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_img_width/2, 210));
                  idle_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_dot_width/2, 210));
                  idle_distance_TextCircle_unit_angle = toDegree(Math.atan2(idle_distance_TextCircle_unit_width/2, 210));
                  // alignment = RIGHT
                  let idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_img_angle * (idle_distance_circle_string.length - 1);
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset - idle_distance_TextCircle_img_angle + idle_distance_TextCircle_dot_img_angle;
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset + 1 * (idle_distance_circle_string.length - 1) / 2;
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset + (idle_distance_TextCircle_img_angle + idle_distance_TextCircle_unit_angle + 1) / 2;
                  idle_distance_TextCircle_angleOffset = -idle_distance_TextCircle_angleOffset;
                  char_Angle -= 2 * idle_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_img_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, idle_distance_TextCircle_ASCIIARRAY[charCode]);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_distance_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= idle_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_dot_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, '0126_4.png');
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_distance_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= idle_distance_TextCircle_unit_angle;
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 36,
                      end_angle: 92,
                      radius: 210,
                      line_width: 40,
                      corner_flag: 3,
                      color: 0xFF7F7F7F,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 230,
                      end_angle: 310,
                      radius: 109,
                      line_width: 40,
                      corner_flag: 3,
                      color: 0xFF595959,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 71,
                      end_angle: 127,
                      radius: 209,
                      line_width: 40,
                      corner_flag: 3,
                      color: 0xFFADADAD,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}